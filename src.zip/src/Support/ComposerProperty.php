<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:35              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Support; use Illuminate\Contracts\Support\Arrayable; use Illuminate\Support\Arr; class ComposerProperty implements Arrayable { protected array $attributes = []; public function __construct(array $ZG2_m = []) { $this->attributes = $ZG2_m; } public function get($W48ry, $jy6Fm = null) { return Arr::get($this->attributes, $W48ry, $jy6Fm); } public function set($W48ry, $Gma7X) { goto c_cCk; pgBYZ: Arr::set($safbJ, $W48ry, $Gma7X); goto dGOcS; c_cCk: $safbJ = $this->attributes; goto pgBYZ; dGOcS: return new static($safbJ); goto iqJjv; iqJjv: } public function delete($W48ry) { goto B42v0; YqjIc: Arr::forget($safbJ, $W48ry); goto zN4q9; B42v0: $safbJ = $this->attributes; goto YqjIc; zN4q9: return new static($safbJ); goto HXnQd; HXnQd: } public function __get($hFAt5) { return $this->get(str_replace("\x5f", "\x2d", $hFAt5)); } public function toArray() { return $this->attributes; } public function toJson() { return json_encode($this->toArray()); } }
