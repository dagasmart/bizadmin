<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:36              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Support\Cores; use DagaSmart\BizAdmin\Admin; use DagaSmart\BizAdmin\Services\AdminRelationshipService; class Relationships { public static function boot() { goto MQTyo; mdBwD: foreach ($nwZEo as $e5FYX) { try { $e5FYX->model::resolveRelationUsing($e5FYX->title, function ($LGos4) use($e5FYX) { $u3OkQ = $e5FYX->method; return $LGos4->{$u3OkQ}(...array_column($e5FYX->buildArgs(), "\166\141\x6c\x75\145")); }); } catch (\Throwable $OiXs7) { } YpfRC: } goto r5p72; zKFQT: return; goto Bc4s7; r5p72: J4cVd: goto Za0VL; f2_gh: if (!blank($nwZEo)) { goto xHuuI; } goto zKFQT; jBsF6: XIvjA: goto RhGSj; Bc4s7: xHuuI: goto mdBwD; l5ad8: return; goto jBsF6; RhGSj: $nwZEo = $u24CR->make()->getAll(); goto f2_gh; L90sz: if (Admin::hasTable($u24CR->getModel()->getTable())) { goto XIvjA; } goto l5ad8; MQTyo: $u24CR = new AdminRelationshipService(); goto L90sz; Za0VL: } }
