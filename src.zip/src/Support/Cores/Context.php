<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:35              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Support\Cores; use Illuminate\Support\Arr; use Illuminate\Support\Fluent; use DagaSmart\BizAdmin\Support\Helper; class Context extends Fluent { public function set($W48ry, $b5EKT = null) { goto F3keC; F3keC: $Uv4qm = is_array($W48ry) ? $W48ry : [$W48ry => $b5EKT]; goto UBoeH; J4FVe: dvPNO: goto iQP9d; iQP9d: return $this; goto vokHI; UBoeH: foreach ($Uv4qm as $W48ry => $b5EKT) { Arr::set($this->attributes, $W48ry, $b5EKT); h3Mox: } goto J4FVe; vokHI: } public function get($W48ry, $jy6Fm = null) { return Arr::get($this->attributes, $W48ry, $jy6Fm); } public function remember($W48ry, \Closure $st03P) { goto J01A0; oPdC0: c2Bga: goto BhmA0; J01A0: if (!(($b5EKT = $this->get($W48ry)) !== null)) { goto c2Bga; } goto YnM9C; BhmA0: return tap($st03P(), function ($b5EKT) use($W48ry) { $this->set($W48ry, $b5EKT); }); goto scKGc; YnM9C: return $b5EKT; goto oPdC0; scKGc: } public function getArray($W48ry, $jy6Fm = null) { return Helper::array($this->get($W48ry, $jy6Fm), false); } public function add($W48ry, $b5EKT, $G95dL = null) { goto FbHK8; KNRJe: qpTKT: goto kG36R; kG36R: return $this->set($W48ry, $qtzwa); goto w5ZgL; gt2ft: $qtzwa[$G95dL] = $b5EKT; goto CIVXW; WTysy: OZejK: goto cjrR2; t5OHB: if ($G95dL === null) { goto OZejK; } goto gt2ft; cjrR2: $qtzwa[] = $b5EKT; goto KNRJe; FbHK8: $qtzwa = $this->getArray($W48ry); goto t5OHB; CIVXW: goto qpTKT; goto WTysy; w5ZgL: } public function merge($W48ry, array $b5EKT) { $qtzwa = $this->getArray($W48ry); return $this->set($W48ry, array_merge($qtzwa, $b5EKT)); } public function forget($fBjUi) { Arr::forget($this->attributes, $fBjUi); } public function flush() { $this->attributes = []; } }
