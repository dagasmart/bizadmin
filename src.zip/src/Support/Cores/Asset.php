<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:35              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Support\Cores; class Asset { protected array $js = []; protected array $css = []; protected array $scripts = []; protected array $styles = []; protected $appendNav; protected $prependNav; private function assetsHandler($qjPie, $biktU) { goto VyUOc; Q3yAj: goto EOdLY; goto jYlid; jYlid: wFkN9: goto TN5tz; VyUOc: if (!is_null($biktU)) { goto Jkuqy; } goto J_cyu; XH7qW: return $this; goto XCOAB; J_cyu: return $this->{$qjPie}; goto TQS91; Wfc3e: $this->{$qjPie}[] = $biktU; goto Q3yAj; S689D: EOdLY: goto XH7qW; TN5tz: $this->{$qjPie} = array_merge($this->{$qjPie}, $biktU); goto S689D; lhxdJ: if (is_array($biktU)) { goto wFkN9; } goto Wfc3e; TQS91: Jkuqy: goto lhxdJ; XCOAB: } public function js($smbSw = null) { return $this->assetsHandler("\x6a\x73", $smbSw); } public function css($yMjlh = null) { return $this->assetsHandler("\x63\x73\163", $yMjlh); } public function scripts($x7MRT = null) { return $this->assetsHandler("\x73\143\162\151\160\x74\x73", $x7MRT); } public function styles($AJpng = null) { return $this->assetsHandler("\x73\x74\171\x6c\x65\163", $AJpng); } public function appendNav($tyaun = null) { goto kJfIM; xnYbG: return $this; goto xjnax; kJfIM: if (!is_null($tyaun)) { goto GCN4r; } goto ItRPf; z2cSX: $this->appendNav = $tyaun; goto xnYbG; jI0oA: GCN4r: goto z2cSX; ItRPf: return $this->appendNav; goto jI0oA; xjnax: } public function prependNav($xi3f0 = null) { goto cFDqG; BnsJ0: return $this; goto ohqbQ; t4Ztq: $this->prependNav = $xi3f0; goto BnsJ0; cFDqG: if (!is_null($xi3f0)) { goto jRJNQ; } goto UyEJj; UyEJj: return $this->prependNav; goto hTk9G; hTk9G: jRJNQ: goto t4Ztq; ohqbQ: } }
