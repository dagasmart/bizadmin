<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:35              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Support; use Composer\Autoload\ClassLoader; class Composer { protected static array $files = []; protected static $loader; public static function loader() { goto Reggr; DVKAw: Jk0z1: goto xNJLc; xNJLc: return static::$loader; goto OU5qd; Reggr: if (static::$loader) { goto Jk0z1; } goto GCO3s; GCO3s: static::$loader = (include base_path() . "\57\166\145\156\x64\x6f\x72\x2f\141\x75\164\x6f\x6c\157\x61\144\56\160\x68\160"); goto DVKAw; OU5qd: } public static function parse(?string $ICl39) { return new ComposerProperty(static::fromJson($ICl39)); } public static function getVersion(?string $rqqCE, ?string $gKE79 = null) { goto vdCzQ; W3PJm: $k1Yeg = collect(static::fromJson($gKE79)["\160\x61\x63\153\141\147\x65\163"] ?? [])->filter(function ($b5EKT) use($rqqCE) { return $b5EKT["\156\x61\x6d\145"] == $rqqCE; })->first(); goto wdy7o; iJspr: HJXqR: goto lmugA; wdy7o: return $k1Yeg["\x76\145\x72\163\x69\x6f\156"] ?? null; goto Qz0bv; XtREc: return null; goto iJspr; vdCzQ: if ($rqqCE) { goto HJXqR; } goto XtREc; lmugA: $gKE79 = $gKE79 ?: base_path("\x63\x6f\155\160\157\x73\145\x72\56\154\x6f\143\x6b"); goto W3PJm; Qz0bv: } public static function fromJson(?string $ICl39) { goto I19iw; Ibu8p: if (!(!$ICl39 || !is_file($ICl39))) { goto MMVk6; } goto MJEta; MJEta: return static::$files[$ICl39] = []; goto UfpuB; I19iw: if (!isset(static::$files[$ICl39])) { goto iVkh9; } goto QlO95; ffxiu: iVkh9: goto Ibu8p; zP4_m: try { return static::$files[$ICl39] = (array) json_decode(app("\146\151\154\145\163")->get($ICl39), true); } catch (\Throwable $OiXs7) { } goto d9ZE7; QlO95: return static::$files[$ICl39]; goto ffxiu; d9ZE7: return static::$files[$ICl39] = []; goto jcYdk; UfpuB: MMVk6: goto zP4_m; jcYdk: } }
