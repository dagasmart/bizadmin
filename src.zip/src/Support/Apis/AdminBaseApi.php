<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:35              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Support\Apis; use Illuminate\Support\Str; use DagaSmart\BizAdmin\Services\AdminService; use DagaSmart\BizAdmin\Services\AdminApiService; use Illuminate\Database\Eloquent\HigherOrderBuilderProxy; abstract class AdminBaseApi implements AdminApiInterface { public string $title = ''; public string $method = "\141\x6e\x79"; public static $apiRecord; public function getTitle() { return $this->title ?: Str::of(static::class)->explode("\134")->pop(); } public function getMethod() { return $this->method; } public function getApiRecord() { goto drftP; frdvT: J0koP: goto SjHtS; iuFf3: self::$apiRecord = AdminApiService::make()->getApiByTemplate(static::class); goto frdvT; drftP: if (self::$apiRecord) { goto J0koP; } goto iuFf3; SjHtS: return self::$apiRecord; goto v_xM9; v_xM9: } public function setApiRecord($iWCBc) { self::$apiRecord = $iWCBc; return $this; } public function getArgs($W48ry = null, $jy6Fm = null) { goto vrEwY; UqoOW: if (!$W48ry) { goto b0wCL; } goto ZHaeR; ZHaeR: return data_get($wjHv9, $W48ry, $jy6Fm); goto ZYy0W; ZYy0W: b0wCL: goto uG70M; vrEwY: $wjHv9 = $this->getApiRecord()->args; goto UqoOW; uG70M: return $wjHv9; goto K5LIi; K5LIi: } public function blankService() { return new class extends AdminService { }; } }
