<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:36              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Traits; trait CheckActionTrait { public function actionOfGetData() { return request()->_action == "\147\x65\164\x44\x61\164\x61"; } public function actionOfExport() { return request()->_action == "\145\170\x70\157\162\164"; } public function actionOfQuickEdit() { return request()->_action == "\x71\x75\151\x63\x6b\x45\144\x69\x74"; } public function actionOfQuickEditItem() { return request()->_action == "\161\165\x69\x63\x6b\105\x64\151\164\111\x74\145\x6d"; } }
