<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:33              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Toast extends BaseRenderer { public function __construct() { } public function body($b5EKT = '') { return $this->set("\x62\x6f\x64\x79", $b5EKT); } public function closeButton($b5EKT = true) { return $this->set("\x63\x6c\x6f\163\145\102\x75\164\x74\x6f\156", $b5EKT); } public function items($b5EKT = '') { return $this->set("\x69\x74\145\155\x73", $b5EKT); } public function level($b5EKT = '') { return $this->set("\154\x65\x76\x65\154", $b5EKT); } public function position($b5EKT = '') { return $this->set("\160\157\163\151\x74\x69\157\x6e", $b5EKT); } public function showIcon($b5EKT = true) { return $this->set("\163\x68\157\167\x49\x63\x6f\156", $b5EKT); } public function timeout($b5EKT = '') { return $this->set("\164\151\x6d\145\157\165\x74", $b5EKT); } public function title($b5EKT = '') { return $this->set("\164\151\164\x6c\x65", $b5EKT); } }
