<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class GridColumn extends BaseRenderer { public function __construct() { } public function body($b5EKT = '') { return $this->set("\142\x6f\x64\x79", $b5EKT); } public function columnClassName($b5EKT = '') { return $this->set("\143\x6f\x6c\x75\155\x6e\103\x6c\141\163\163\x4e\141\x6d\x65", $b5EKT); } public function horizontal($b5EKT = '') { return $this->set("\150\157\x72\151\x7a\157\x6e\x74\141\154", $b5EKT); } public function id($b5EKT = '') { return $this->set("\151\144", $b5EKT); } public function lg($b5EKT = '') { return $this->set("\154\147", $b5EKT); } public function md($b5EKT = '') { return $this->set("\155\144", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\155\x6f\144\145", $b5EKT); } public function sm($b5EKT = '') { return $this->set("\163\x6d", $b5EKT); } public function style($b5EKT = '') { return $this->set("\163\164\x79\154\145", $b5EKT); } public function themeCss($b5EKT = '') { return $this->set("\x74\x68\145\155\x65\x43\163\163", $b5EKT); } public function valign($b5EKT = '') { return $this->set("\x76\x61\154\x69\147\156", $b5EKT); } public function wrapperCustomStyle($b5EKT = '') { return $this->set("\x77\162\x61\160\x70\145\x72\103\165\163\164\157\x6d\x53\164\x79\154\x65", $b5EKT); } public function xs($b5EKT = '') { return $this->set("\x78\x73", $b5EKT); } }
