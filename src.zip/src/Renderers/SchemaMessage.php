<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class SchemaMessage extends BaseRenderer { public function __construct() { } public function fetchFailed($b5EKT = '') { return $this->set("\146\145\x74\x63\150\106\x61\151\x6c\x65\x64", $b5EKT); } public function fetchSuccess($b5EKT = '') { return $this->set("\x66\x65\164\x63\150\x53\x75\143\x63\x65\x73\x73", $b5EKT); } public function saveFailed($b5EKT = '') { return $this->set("\x73\x61\x76\145\106\x61\151\x6c\145\x64", $b5EKT); } public function saveSuccess($b5EKT = '') { return $this->set("\163\141\166\x65\123\165\143\143\x65\163\163", $b5EKT); } }
