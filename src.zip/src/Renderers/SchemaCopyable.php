<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class SchemaCopyable extends BaseRenderer { public function __construct() { } public function content($b5EKT = '') { return $this->set("\143\x6f\x6e\x74\145\x6e\x74", $b5EKT); } public function icon($b5EKT = '') { return $this->set("\x69\x63\157\156", $b5EKT); } public function tooltip($b5EKT = '') { return $this->set("\164\157\x6f\154\x74\x69\x70", $b5EKT); } }
