<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class IconItem extends BaseRenderer { public function __construct() { } public function icon($b5EKT = '') { return $this->set("\151\143\x6f\156", $b5EKT); } public function position($b5EKT = '') { return $this->set("\160\x6f\163\151\164\151\x6f\156", $b5EKT); } }
