<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class HBoxColumn extends BaseRenderer { public function __construct() { } public function body($b5EKT = '') { return $this->set("\142\157\x64\x79", $b5EKT); } public function columnClassName($b5EKT = '') { return $this->set("\x63\x6f\x6c\165\155\156\x43\x6c\x61\163\163\116\141\x6d\145", $b5EKT); } public function height($b5EKT = '') { return $this->set("\x68\x65\151\x67\x68\x74", $b5EKT); } public function horizontal($b5EKT = '') { return $this->set("\150\157\x72\x69\172\x6f\x6e\x74\141\154", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\155\x6f\x64\145", $b5EKT); } public function style($b5EKT = '') { return $this->set("\163\164\x79\154\145", $b5EKT); } public function valign($b5EKT = '') { return $this->set("\x76\141\154\151\147\x6e", $b5EKT); } public function visible($b5EKT = true) { return $this->set("\166\x69\163\151\x62\154\145", $b5EKT); } public function visibleOn($b5EKT = '') { return $this->set("\x76\151\163\x69\142\154\145\117\156", $b5EKT); } public function width($b5EKT = '') { return $this->set("\167\151\x64\x74\150", $b5EKT); } }
