<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Property extends BaseRenderer { public function __construct() { $this->set("\x74\171\x70\x65", "\x70\x72\x6f\160\145\162\x74\x79"); } public function className($b5EKT = '') { return $this->set("\x63\x6c\141\163\163\116\141\155\x65", $b5EKT); } public function column($b5EKT = '') { return $this->set("\143\157\x6c\x75\x6d\x6e", $b5EKT); } public function contentStyle($b5EKT = '') { return $this->set("\x63\157\x6e\x74\x65\x6e\164\123\164\x79\x6c\x65", $b5EKT); } public function items($b5EKT = '') { return $this->set("\151\x74\x65\x6d\163", $b5EKT); } public function labelStyle($b5EKT = '') { return $this->set("\x6c\141\x62\145\x6c\x53\164\171\x6c\145", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\x6d\x6f\144\145", $b5EKT); } public function separator($b5EKT = '') { return $this->set("\163\x65\160\x61\162\141\164\x6f\162", $b5EKT); } public function source($b5EKT = '') { return $this->set("\x73\x6f\x75\x72\143\x65", $b5EKT); } public function style($b5EKT = '') { return $this->set("\x73\164\x79\154\145", $b5EKT); } public function title($b5EKT = '') { return $this->set("\164\x69\164\154\145", $b5EKT); } public function type($b5EKT = "\x70\x72\157\160\x65\162\164\x79") { return $this->set("\x74\171\x70\x65", $b5EKT); } }
