<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Expandable extends BaseRenderer { public function __construct() { } public function expandableOn($b5EKT = '') { return $this->set("\145\170\x70\141\x6e\144\141\x62\x6c\x65\117\156", $b5EKT); } public function expandedRowClassNameExpr($b5EKT = '') { return $this->set("\145\170\x70\x61\156\144\x65\x64\122\x6f\x77\103\154\141\x73\x73\116\x61\155\145\x45\170\160\162", $b5EKT); } public function expandedRowKeys($b5EKT = '') { return $this->set("\145\x78\160\x61\x6e\x64\x65\144\x52\x6f\167\113\x65\171\163", $b5EKT); } public function expandedRowKeysExpr($b5EKT = '') { return $this->set("\145\170\x70\141\x6e\x64\x65\x64\122\157\167\x4b\x65\171\x73\x45\170\x70\x72", $b5EKT); } public function keyField($b5EKT = '') { return $this->set("\x6b\x65\171\x46\151\145\154\144", $b5EKT); } public function type($b5EKT = '') { return $this->set("\x74\171\x70\145", $b5EKT); } }
