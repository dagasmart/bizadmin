<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class SchemaPopOver extends BaseRenderer { public function __construct() { } public function body($b5EKT = '') { return $this->set("\x62\x6f\144\x79", $b5EKT); } public function className($b5EKT = '') { return $this->set("\143\x6c\x61\x73\163\x4e\141\x6d\145", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\x6d\157\x64\x65", $b5EKT); } public function offset($b5EKT = '') { return $this->set("\x6f\x66\x66\x73\145\x74", $b5EKT); } public function popOverClassName($b5EKT = '') { return $this->set("\160\157\160\117\x76\x65\x72\x43\x6c\x61\x73\163\116\141\x6d\145", $b5EKT); } public function popOverEnableOn($b5EKT = '') { return $this->set("\160\x6f\x70\117\166\145\162\x45\x6e\x61\x62\154\x65\x4f\x6e", $b5EKT); } public function position($b5EKT = '') { return $this->set("\x70\157\163\x69\164\151\157\x6e", $b5EKT); } public function showIcon($b5EKT = true) { return $this->set("\x73\150\x6f\x77\x49\143\x6f\x6e", $b5EKT); } public function size($b5EKT = '') { return $this->set("\x73\151\172\145", $b5EKT); } public function title($b5EKT = '') { return $this->set("\x74\151\x74\154\145", $b5EKT); } public function trigger($b5EKT = '') { return $this->set("\x74\x72\x69\147\147\x65\x72", $b5EKT); } }
