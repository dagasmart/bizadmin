<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class RowSelection extends BaseRenderer { public function __construct() { } public function columnWidth($b5EKT = '') { return $this->set("\x63\x6f\154\165\x6d\x6e\127\x69\144\x74\x68", $b5EKT); } public function disableOn($b5EKT = '') { return $this->set("\144\x69\163\x61\142\x6c\145\117\156", $b5EKT); } public function keyField($b5EKT = '') { return $this->set("\153\x65\x79\x46\x69\x65\x6c\144", $b5EKT); } public function rowClick($b5EKT = true) { return $this->set("\x72\x6f\x77\103\x6c\x69\x63\153", $b5EKT); } public function selectedRowKeys($b5EKT = '') { return $this->set("\163\145\154\145\143\164\145\x64\x52\x6f\167\113\145\x79\x73", $b5EKT); } public function selectedRowKeysExpr($b5EKT = '') { return $this->set("\163\x65\154\x65\x63\x74\x65\144\122\x6f\167\113\x65\x79\x73\105\x78\x70\x72", $b5EKT); } public function selections($b5EKT = '') { return $this->set("\x73\145\x6c\145\143\x74\x69\x6f\156\x73", $b5EKT); } public function type($b5EKT = '') { return $this->set("\x74\171\160\145", $b5EKT); } }
