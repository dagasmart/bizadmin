<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class CRUDToolbar extends BaseRenderer { public function __construct() { } public function align($b5EKT = '') { return $this->set("\141\154\x69\x67\156", $b5EKT); } public function itemCheckableOn($b5EKT = '') { return $this->set("\151\164\145\155\x43\150\x65\x63\x6b\141\x62\x6c\x65\x4f\156", $b5EKT); } }
