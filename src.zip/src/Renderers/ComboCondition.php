<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class ComboCondition extends BaseRenderer { public function __construct() { } public function items($b5EKT = '') { return $this->set("\x69\164\x65\x6d\x73", $b5EKT); } public function label($b5EKT = '') { return $this->set("\x6c\x61\142\145\x6c", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\155\x6f\144\x65", $b5EKT); } public function scaffold($b5EKT = '') { return $this->set("\163\143\141\x66\x66\157\154\x64", $b5EKT); } public function test($b5EKT = '') { return $this->set("\x74\145\163\164", $b5EKT); } }
