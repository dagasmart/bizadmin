<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class RowSelectionOptions extends BaseRenderer { public function __construct() { } public function key($b5EKT = '') { return $this->set("\x6b\145\171", $b5EKT); } public function text($b5EKT = '') { return $this->set("\x74\145\170\164", $b5EKT); } }
