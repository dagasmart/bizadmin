<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class AutoFillHeight extends BaseRenderer { public function __construct() { } public function height($b5EKT = '') { return $this->set("\x68\145\x69\147\x68\x74", $b5EKT); } public function maxHeight($b5EKT = '') { return $this->set("\155\141\170\110\x65\151\147\150\x74", $b5EKT); } }
