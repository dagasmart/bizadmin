<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class ConditionGroupValue extends BaseRenderer { public function __construct() { $this->set("\143\x6f\156\152\x75\x6e\x63\164\x69\157\x6e", "\141\156\144"); } public function children($b5EKT = '') { return $this->set("\x63\150\151\154\x64\162\145\156", $b5EKT); } public function conjunction($b5EKT = '') { return $this->set("\143\157\x6e\x6a\x75\156\x63\164\151\157\x6e", $b5EKT); } public function id($b5EKT = '') { return $this->set("\151\x64", $b5EKT); } public function if($b5EKT = '') { return $this->set("\x69\146", $b5EKT); } public function not($b5EKT = true) { return $this->set("\156\157\164", $b5EKT); } }
