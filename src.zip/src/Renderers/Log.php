<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Log extends BaseRenderer { public function __construct() { $this->set("\164\171\160\x65", "\x6c\157\x67"); } public function autoScroll($b5EKT = '') { return $this->set("\141\x75\164\157\x53\x63\x72\157\x6c\x6c", $b5EKT); } public function className($b5EKT = '') { return $this->set("\x63\x6c\x61\x73\x73\116\x61\x6d\145", $b5EKT); } public function disableColor($b5EKT = '') { return $this->set("\144\x69\163\x61\142\154\145\103\x6f\154\157\162", $b5EKT); } public function encoding($b5EKT = '') { return $this->set("\145\156\143\x6f\x64\x69\x6e\147", $b5EKT); } public function height($b5EKT = '') { return $this->set("\150\x65\x69\x67\150\164", $b5EKT); } public function maxLength($b5EKT = '') { return $this->set("\155\x61\x78\114\145\156\x67\164\150", $b5EKT); } public function operation($b5EKT = '') { return $this->set("\x6f\x70\x65\162\x61\164\151\x6f\x6e", $b5EKT); } public function placeholder($b5EKT = '') { return $this->set("\x70\154\141\x63\x65\x68\x6f\154\144\x65\162", $b5EKT); } public function rowHeight($b5EKT = '') { return $this->set("\162\157\x77\110\x65\x69\147\x68\164", $b5EKT); } public function source($b5EKT = '') { return $this->set("\x73\157\x75\x72\x63\145", $b5EKT); } public function type($b5EKT = "\154\x6f\147") { return $this->set("\x74\171\x70\145", $b5EKT); } }
