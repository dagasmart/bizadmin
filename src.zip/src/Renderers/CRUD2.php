<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class CRUD2 extends BaseRenderer { public function itemCheckableOn($b5EKT = '') { return $this->set("\151\x74\145\x6d\103\x68\145\x63\153\141\x62\154\x65\117\x6e", $b5EKT); } }
