<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Markdown extends BaseRenderer { public function __construct() { $this->set("\x74\x79\160\145", "\155\141\x72\x6b\x64\x6f\x77\156"); } public function className($b5EKT = '') { return $this->set("\143\154\141\163\x73\116\141\x6d\x65", $b5EKT); } public function name($b5EKT = '') { return $this->set("\156\141\x6d\x65", $b5EKT); } public function options($b5EKT = '') { return $this->set("\157\160\x74\x69\157\x6e\x73", $b5EKT); } public function src($b5EKT = '') { return $this->set("\163\162\x63", $b5EKT); } public function type($b5EKT = "\x6d\141\x72\x6b\144\157\x77\156") { return $this->set("\x74\x79\x70\x65", $b5EKT); } public function value($b5EKT = '') { return $this->set("\x76\x61\x6c\165\145", $b5EKT); } }
