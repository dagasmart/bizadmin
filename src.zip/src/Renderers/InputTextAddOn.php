<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class InputTextAddOn extends BaseRenderer { public function __construct() { } public function position($b5EKT = '') { return $this->set("\160\157\163\151\x74\x69\x6f\x6e", $b5EKT); } }
