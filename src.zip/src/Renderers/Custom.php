<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Custom extends BaseRenderer { public function __construct() { $this->set("\x74\171\160\x65", "\x63\x75\x73\x74\x6f\155"); } public function className($b5EKT = '') { return $this->set("\143\154\x61\163\163\116\x61\x6d\x65", $b5EKT); } public function html($b5EKT = '') { return $this->set("\150\x74\155\x6c", $b5EKT); } public function id($b5EKT = '') { return $this->set("\x69\x64", $b5EKT); } public function inline($b5EKT = true) { return $this->set("\151\x6e\154\x69\156\x65", $b5EKT); } public function name($b5EKT = '') { return $this->set("\x6e\x61\x6d\x65", $b5EKT); } public function onMount($b5EKT = '') { return $this->set("\157\x6e\115\157\165\156\164", $b5EKT); } public function onUnmount($b5EKT = '') { return $this->set("\x6f\156\125\156\x6d\x6f\165\156\164", $b5EKT); } public function onUpdate($b5EKT = '') { return $this->set("\157\x6e\x55\x70\x64\x61\x74\x65", $b5EKT); } public function type($b5EKT = "\143\165\x73\164\x6f\155") { return $this->set("\x74\171\x70\145", $b5EKT); } }
