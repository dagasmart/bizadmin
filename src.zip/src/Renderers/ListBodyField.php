<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class ListBodyField extends BaseRenderer { public function __construct() { } public function copyable($b5EKT = true) { return $this->set("\143\157\x70\x79\141\x62\x6c\145", $b5EKT); } public function innerClassName($b5EKT = '') { return $this->set("\151\156\x6e\x65\x72\x43\154\x61\x73\163\116\141\155\x65", $b5EKT); } public function label($b5EKT = '') { return $this->set("\154\x61\142\145\x6c", $b5EKT); } public function labelClassName($b5EKT = '') { return $this->set("\154\141\142\145\x6c\x43\x6c\141\x73\163\116\141\155\x65", $b5EKT); } public function name($b5EKT = '') { return $this->set("\x6e\x61\x6d\x65", $b5EKT); } public function popOver($b5EKT = '') { return $this->set("\160\157\x70\117\x76\145\x72", $b5EKT); } public function quickEdit($b5EKT = '') { return $this->set("\161\x75\x69\x63\x6b\105\144\x69\164", $b5EKT); } }
