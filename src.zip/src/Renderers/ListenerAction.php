<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class ListenerAction extends BaseRenderer { public function __construct() { } public function actionType($b5EKT = '') { return $this->set("\141\143\164\151\x6f\156\124\x79\x70\x65", $b5EKT); } public function args($b5EKT = '') { return $this->set("\141\x72\147\163", $b5EKT); } public function componentId($b5EKT = '') { return $this->set("\143\x6f\155\x70\x6f\x6e\145\156\164\111\144", $b5EKT); } public function componentName($b5EKT = '') { return $this->set("\x63\x6f\155\160\157\156\x65\x6e\164\116\x61\155\x65", $b5EKT); } public function confirmTitle($b5EKT = '') { return $this->set("\143\x6f\x6e\x66\151\162\x6d\x54\151\x74\154\145", $b5EKT); } public function data($b5EKT = '') { return $this->set("\x64\x61\x74\x61", $b5EKT); } public function dataMergeMode($b5EKT = '') { return $this->set("\144\x61\x74\x61\115\145\162\147\145\115\157\x64\145", $b5EKT); } public function description($b5EKT = '') { return $this->set("\x64\145\163\143\x72\151\160\x74\x69\157\156", $b5EKT); } public function execOn($b5EKT = '') { return $this->set("\x65\170\x65\143\x4f\156", $b5EKT); } public function expression($b5EKT = '') { return $this->set("\x65\170\160\162\145\x73\x73\x69\x6f\156", $b5EKT); } public function ignoreError($b5EKT = true) { return $this->set("\x69\147\x6e\157\162\x65\x45\x72\162\157\162", $b5EKT); } public function outputVar($b5EKT = '') { return $this->set("\x6f\x75\164\160\165\164\x56\141\162", $b5EKT); } public function preventDefault($b5EKT = true) { return $this->set("\x70\x72\x65\x76\x65\x6e\x74\x44\145\x66\x61\x75\x6c\x74", $b5EKT); } public function stopPropagation($b5EKT = true) { return $this->set("\x73\x74\x6f\x70\x50\162\157\x70\x61\147\141\x74\151\157\x6e", $b5EKT); } }
