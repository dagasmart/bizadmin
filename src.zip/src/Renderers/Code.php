<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:30              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Code extends BaseRenderer { public function __construct() { $this->set("\164\x79\160\x65", "\x63\157\x64\145"); } public function className($b5EKT = '') { return $this->set("\143\154\141\163\163\116\x61\x6d\x65", $b5EKT); } public function editorTheme($b5EKT = '') { return $this->set("\145\144\x69\x74\157\162\124\150\145\x6d\x65", $b5EKT); } public function language($b5EKT = '') { return $this->set("\154\141\156\147\165\141\x67\x65", $b5EKT); } public function name($b5EKT = '') { return $this->set("\156\x61\155\x65", $b5EKT); } public function tabSize($b5EKT = '') { return $this->set("\x74\x61\x62\x53\151\172\x65", $b5EKT); } public function type($b5EKT = "\143\157\x64\145") { return $this->set("\164\x79\160\145", $b5EKT); } public function value($b5EKT = '') { return $this->set("\166\141\x6c\165\145", $b5EKT); } public function wordWrap($b5EKT = true) { return $this->set("\167\157\162\x64\x57\x72\141\160", $b5EKT); } }
