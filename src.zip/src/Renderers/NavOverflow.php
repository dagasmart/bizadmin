<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class NavOverflow extends BaseRenderer { public function __construct() { } public function enable($b5EKT = true) { return $this->set("\145\156\x61\x62\x6c\145", $b5EKT); } public function itemWidth($b5EKT = '') { return $this->set("\x69\x74\x65\155\127\151\x64\x74\150", $b5EKT); } public function maxVisibleCount($b5EKT = '') { return $this->set("\x6d\x61\x78\x56\151\x73\x69\x62\154\145\103\x6f\165\156\164", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\x6d\x6f\144\145", $b5EKT); } public function overflowClassName($b5EKT = '') { return $this->set("\x6f\166\x65\x72\146\154\157\x77\x43\154\141\x73\163\x4e\141\155\145", $b5EKT); } public function overflowIndicator($b5EKT = '') { return $this->set("\x6f\x76\145\x72\x66\x6c\x6f\167\111\156\x64\151\143\141\164\157\x72", $b5EKT); } public function overflowLabel($b5EKT = '') { return $this->set("\x6f\x76\145\x72\146\x6c\x6f\x77\x4c\141\x62\145\x6c", $b5EKT); } public function overflowListClassName($b5EKT = '') { return $this->set("\x6f\166\145\x72\146\x6c\x6f\167\x4c\x69\163\164\103\x6c\x61\x73\163\116\141\x6d\x65", $b5EKT); } public function overflowPopoverClassName($b5EKT = '') { return $this->set("\157\x76\x65\162\146\x6c\x6f\x77\x50\157\160\157\166\x65\162\x43\154\x61\x73\163\x4e\x61\x6d\145", $b5EKT); } public function overflowSuffix($b5EKT = '') { return $this->set("\157\166\x65\x72\x66\154\157\167\x53\x75\146\x66\151\x78", $b5EKT); } public function style($b5EKT = '') { return $this->set("\163\x74\x79\154\x65", $b5EKT); } public function wrapperComponent($b5EKT = '') { return $this->set("\x77\x72\141\x70\160\145\x72\x43\157\155\160\x6f\156\145\156\x74", $b5EKT); } }
