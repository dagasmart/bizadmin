<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Badge extends BaseRenderer { public function __construct() { } public function animation($b5EKT = true) { return $this->set("\141\x6e\x69\x6d\x61\164\x69\157\156", $b5EKT); } public function className($b5EKT = '') { return $this->set("\143\154\141\163\x73\116\141\x6d\x65", $b5EKT); } public function level($b5EKT = '') { return $this->set("\154\145\x76\x65\154", $b5EKT); } public function mode($b5EKT = '') { return $this->set("\155\x6f\x64\x65", $b5EKT); } public function offset($b5EKT = '') { return $this->set("\157\x66\146\x73\x65\164", $b5EKT); } public function overflowCount($b5EKT = '') { return $this->set("\x6f\x76\145\162\x66\154\157\167\x43\157\165\x6e\x74", $b5EKT); } public function position($b5EKT = '') { return $this->set("\160\157\163\151\164\151\x6f\156", $b5EKT); } public function size($b5EKT = '') { return $this->set("\x73\x69\172\145", $b5EKT); } public function style($b5EKT = '') { return $this->set("\163\x74\x79\x6c\145", $b5EKT); } public function text($b5EKT = '') { return $this->set("\x74\145\170\x74", $b5EKT); } public function visibleOn($b5EKT = '') { return $this->set("\166\151\163\151\142\x6c\x65\117\x6e", $b5EKT); } }
