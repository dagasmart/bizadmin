<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:31              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class IconChecked extends BaseRenderer { public function __construct() { } public function id($b5EKT = '') { return $this->set("\151\x64", $b5EKT); } public function name($b5EKT = '') { return $this->set("\x6e\141\155\x65", $b5EKT); } public function svg($b5EKT = '') { return $this->set("\x73\x76\x67", $b5EKT); } }
