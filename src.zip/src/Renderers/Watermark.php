<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:34              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Watermark extends BaseRenderer { public function __construct() { $this->set("\164\171\x70\145", "\x63\165\x73\164\157\155\55\x77\141\164\x65\x72\x6d\x61\x72\153"); } public function body($b5EKT = '') { return $this->set("\x62\157\144\x79", $b5EKT); } public function className($b5EKT = '') { return $this->set("\x63\154\x61\x73\x73\116\141\155\x65", $b5EKT); } public function content($b5EKT = '') { return $this->set("\143\x6f\x6e\164\145\156\164", $b5EKT); } public function font($b5EKT = '') { return $this->set("\146\157\x6e\164", $b5EKT); } public function gap($b5EKT = '') { return $this->set("\147\x61\160", $b5EKT); } public function height($b5EKT = '') { return $this->set("\x68\145\151\147\x68\164", $b5EKT); } public function image($b5EKT = '') { return $this->set("\x69\x6d\141\x67\145", $b5EKT); } public function inherit($b5EKT = true) { return $this->set("\151\x6e\150\145\x72\x69\x74", $b5EKT); } public function offset($b5EKT = '') { return $this->set("\157\146\x66\x73\145\x74", $b5EKT); } public function rotate($b5EKT = '') { return $this->set("\x72\157\164\141\x74\x65", $b5EKT); } public function type($b5EKT = "\x63\165\163\x74\x6f\155\x2d\167\141\164\145\162\155\x61\162\153") { return $this->set("\164\171\x70\145", $b5EKT); } public function width($b5EKT = '') { return $this->set("\x77\x69\144\x74\x68", $b5EKT); } public function zIndex($b5EKT = '') { return $this->set("\x7a\x49\x6e\144\145\170", $b5EKT); } }
