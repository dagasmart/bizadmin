<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class SchemaQuickEdit extends BaseRenderer { public function body($b5EKT = '') { return $this->set("\x62\157\x64\x79", $b5EKT); } public function icon($b5EKT = '') { return $this->set("\x69\x63\x6f\x6e", $b5EKT); } public function mode($b5EKT = "\x69\x6e\x6c\x69\156\145") { return $this->set("\155\x6f\x64\x65", $b5EKT); } public function reload($b5EKT = '') { return $this->set("\162\x65\x6c\157\141\x64", $b5EKT); } public function resetOnFailed($b5EKT = true) { return $this->set("\x72\x65\163\x65\x74\x4f\x6e\x46\141\x69\x6c\145\x64", $b5EKT); } public function saveImmediately($b5EKT = true) { return $this->set("\x73\x61\x76\x65\111\x6d\155\145\144\x69\141\x74\145\154\x79", $b5EKT); } }
