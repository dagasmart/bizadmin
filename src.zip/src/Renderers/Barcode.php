<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Barcode extends BaseRenderer { public function __construct() { $this->set("\x74\x79\160\x65", "\x62\x61\162\143\x6f\x64\x65"); } public function className($b5EKT = '') { return $this->set("\143\154\x61\x73\x73\116\141\x6d\x65", $b5EKT); } public function type($b5EKT = "\x62\141\162\x63\157\144\x65") { return $this->set("\164\171\x70\x65", $b5EKT); } }
