<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class AutoGenerateFilter extends BaseRenderer { public function __construct() { } public function columnsNum($b5EKT = '') { return $this->set("\143\x6f\154\165\155\156\163\116\x75\155", $b5EKT); } public function defaultCollapsed($b5EKT = true) { return $this->set("\x64\145\x66\x61\x75\x6c\164\x43\x6f\154\154\x61\160\x73\145\144", $b5EKT); } public function enableBulkActions($b5EKT = true) { return $this->set("\145\x6e\x61\142\154\145\x42\x75\x6c\153\x41\143\x74\151\157\x6e\163", $b5EKT); } public function enableBulkActionsOn($b5EKT = '') { return $this->set("\145\156\x61\x62\x6c\x65\x42\x75\x6c\153\101\x63\x74\151\x6f\156\163\117\x6e", $b5EKT); } public function showBtnToolbar($b5EKT = true) { return $this->set("\x73\150\157\x77\x42\x74\156\124\157\157\154\x62\141\x72", $b5EKT); } }
