<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Option extends BaseRenderer { public function __construct() { } public function children($b5EKT = '') { return $this->set("\x63\150\x69\154\x64\x72\x65\156", $b5EKT); } public function defer($b5EKT = true) { return $this->set("\144\145\146\145\162", $b5EKT); } public function deferApi($b5EKT = '') { return $this->set("\x64\x65\146\x65\162\x41\x70\151", $b5EKT); } public function description($b5EKT = '') { return $this->set("\144\145\163\x63\x72\x69\160\164\151\157\x6e", $b5EKT); } public function disabled($b5EKT = true) { return $this->set("\x64\151\163\x61\142\x6c\x65\x64", $b5EKT); } public function hidden($b5EKT = true) { return $this->set("\x68\x69\144\x64\145\x6e", $b5EKT); } public function label($b5EKT = '') { return $this->set("\154\141\142\145\x6c", $b5EKT); } public function loaded($b5EKT = true) { return $this->set("\x6c\x6f\141\x64\145\144", $b5EKT); } public function loading($b5EKT = true) { return $this->set("\x6c\157\141\x64\x69\156\147", $b5EKT); } public function scopeLabel($b5EKT = '') { return $this->set("\x73\x63\x6f\160\145\114\x61\x62\x65\x6c", $b5EKT); } public function value($b5EKT = '') { return $this->set("\166\141\x6c\x75\145", $b5EKT); } public function visible($b5EKT = true) { return $this->set("\166\x69\x73\x69\142\154\x65", $b5EKT); } }
