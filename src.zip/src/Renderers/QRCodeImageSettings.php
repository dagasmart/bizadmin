<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:32              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class QRCodeImageSettings extends BaseRenderer { public function __construct() { } public function excavate($b5EKT = true) { return $this->set("\145\170\143\x61\166\141\164\145", $b5EKT); } public function height($b5EKT = '') { return $this->set("\150\x65\151\147\150\164", $b5EKT); } public function src($b5EKT = '') { return $this->set("\163\x72\x63", $b5EKT); } public function width($b5EKT = '') { return $this->set("\x77\151\144\x74\x68", $b5EKT); } public function x($b5EKT = '') { return $this->set("\170", $b5EKT); } public function y($b5EKT = '') { return $this->set("\171", $b5EKT); } }
