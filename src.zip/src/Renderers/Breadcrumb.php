<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Renderers; class Breadcrumb extends BaseRenderer { public function __construct() { $this->set("\x74\x79\160\145", "\x62\x72\145\x61\x64\x63\162\x75\x6d\142"); } public function className($b5EKT = '') { return $this->set("\143\154\141\163\x73\x4e\141\x6d\x65", $b5EKT); } public function dropdownClassName($b5EKT = '') { return $this->set("\x64\x72\x6f\160\144\x6f\167\x6e\x43\x6c\141\x73\163\116\141\155\x65", $b5EKT); } public function dropdownItemClassName($b5EKT = '') { return $this->set("\x64\162\x6f\160\x64\157\167\x6e\x49\x74\145\x6d\103\x6c\x61\163\x73\x4e\141\x6d\x65", $b5EKT); } public function itemClassName($b5EKT = '') { return $this->set("\x69\x74\x65\155\x43\x6c\x61\163\163\x4e\141\155\x65", $b5EKT); } public function items($b5EKT = '') { return $this->set("\151\x74\145\155\x73", $b5EKT); } public function labelMaxLength($b5EKT = '') { return $this->set("\154\x61\x62\145\x6c\115\x61\x78\114\145\x6e\147\164\x68", $b5EKT); } public function separator($b5EKT = '') { return $this->set("\x73\x65\x70\141\x72\x61\x74\157\x72", $b5EKT); } public function separatorClassName($b5EKT = '') { return $this->set("\163\x65\160\141\x72\x61\x74\x6f\x72\103\154\x61\x73\x73\116\141\x6d\145", $b5EKT); } public function source($b5EKT = '') { return $this->set("\x73\x6f\x75\162\x63\x65", $b5EKT); } public function tooltipPosition($b5EKT = '') { return $this->set("\x74\157\157\154\x74\x69\160\x50\157\163\151\164\x69\157\x6e", $b5EKT); } public function type($b5EKT = "\x62\x72\x65\x61\x64\x63\x72\165\x6d\x62") { return $this->set("\x74\x79\x70\145", $b5EKT); } }
