<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:28              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use Illuminate\Support\Facades\Storage; use Illuminate\Database\Eloquent\SoftDeletes; class AdminPermissionMenu extends BaseModel { use SoftDeletes; protected $table = "\x61\x64\x6d\151\x6e\137\160\145\162\155\151\163\163\x69\157\x6e\137\x6d\x65\156\165"; }
