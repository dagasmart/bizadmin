<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; class AdminSetting extends BaseModel { protected $table = "\x61\144\x6d\151\x6e\137\x73\145\164\x74\151\156\x67\x73"; protected $primaryKey = "\x69\x64"; protected $guarded = array(); protected $casts = array("\x76\141\154\x75\145\163" => "\152\163\x6f\x6e"); protected function asJson($b5EKT, $valvO = true) { return json_encode($b5EKT, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); } }
