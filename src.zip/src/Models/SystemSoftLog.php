<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use Illuminate\Database\Eloquent\SoftDeletes; use DagaSmart\BizAdmin\Traits\CommonTrait; class SystemSoftLog extends BaseModel { use CommonTrait, SoftDeletes; protected $table = "\x73\171\163\164\145\155\x5f\163\x6f\x66\164\137\154\x6f\x67"; protected $primaryKey = "\x69\x64"; }
