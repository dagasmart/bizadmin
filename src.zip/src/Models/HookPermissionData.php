<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use DagaSmart\BizAdmin\Models\BaseModel as Model; class HookPermissionData extends Model { protected $table = "\x68\x6f\157\x6b\x5f\160\145\x72\155\151\x73\163\151\157\156\137\144\x61\x74\141"; public $timestamps = false; }
