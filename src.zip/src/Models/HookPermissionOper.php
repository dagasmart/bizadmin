<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use DagaSmart\BizAdmin\Models\BaseModel as Model; class HookPermissionOper extends Model { protected $table = "\150\157\157\153\x5f\x70\x65\x72\155\x69\163\x73\151\157\x6e\x5f\157\x70\x65\162"; public $timestamps = false; }
