<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use Illuminate\Support\Facades\DB; use DagaSmart\BizAdmin\Traits\CommonTrait; use Illuminate\Database\Eloquent\SoftDeletes; class SystemMerchantModule extends BaseModel { use CommonTrait, SoftDeletes; protected $table = "\163\171\163\x74\145\155\137\x6d\145\162\x63\150\141\156\164\137\155\157\x64\x75\x6c\145"; public function stateOption() { return [["\154\141\x62\145\x6c" => "\346\230\xaf", "\x76\x61\154\x75\x65" => 1], ["\154\141\x62\x65\154" => "\345\x90\246", "\166\x61\154\165\x65" => 0]]; } public function moduleOption() { goto R0K4k; fl_lU: $qfjJe = 0; goto NE1IT; xzRsh: JJrZU: goto h97VF; e4yBx: if (!($ejlyo = $this->getModules())) { goto JJrZU; } goto fl_lU; h97VF: return $lTLYq; goto oi1Cb; NE1IT: array_walk($ejlyo, function (&$b5EKT, $W48ry) use(&$qfjJe, &$lTLYq) { goto hfe0J; hfe0J: $lTLYq[$qfjJe]["\154\141\x62\145\154"] = $W48ry; goto EPmjR; EPmjR: $lTLYq[$qfjJe]["\166\x61\x6c\x75\x65"] = $W48ry; goto BkW8U; BkW8U: $qfjJe++; goto N_fUG; N_fUG: }); goto xzRsh; R0K4k: $lTLYq = []; goto e4yBx; oi1Cb: } }
