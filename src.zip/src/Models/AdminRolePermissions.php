<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use Illuminate\Support\Facades\Storage; use Illuminate\Database\Eloquent\SoftDeletes; class AdminRolePermissions extends BaseModel { use SoftDeletes; protected $table = "\x61\144\x6d\151\156\137\162\157\154\145\137\x70\145\162\155\151\163\x73\151\157\156\x73"; }
