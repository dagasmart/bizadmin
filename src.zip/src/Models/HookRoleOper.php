<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:29              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Models; use DagaSmart\BizAdmin\Models\BaseModel as Model; class HookRoleOper extends Model { protected $table = "\x68\157\x6f\x6b\137\x72\157\x6c\145\137\157\160\x65\162"; public $timestamps = false; }
