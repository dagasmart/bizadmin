<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:28              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Middleware; use Closure; use Illuminate\Support\Facades\App; class AutoSetLocale { public function handle($LiCd2, Closure $aMp88) { goto zTbV2; jkeeg: return $aMp88($LiCd2); goto OG8hW; wqBHc: App::setLocale($epbyw); goto jkeeg; zTbV2: $epbyw = request()->header("\x6c\x6f\143\x61\154\x65", config("\141\160\x70\x2e\x6c\x6f\143\141\x6c\x65")); goto wqBHc; OG8hW: } }
