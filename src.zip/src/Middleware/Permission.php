<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:28              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Middleware; use Closure; use DagaSmart\BizAdmin\Admin; use Illuminate\Http\Request; class Permission { public function handle(Request $LiCd2, Closure $aMp88, ...$wjHv9) { goto xA7Qg; t5STX: return Admin::response()->fail(admin_trans("\141\144\x6d\x69\156\56\x75\x6e\x61\165\x74\x68\x6f\x72\151\x7a\x65\x64")); goto vIcaI; vIcaI: s2qvp: goto MbEkh; MbEkh: return $aMp88($LiCd2); goto T90ay; xA7Qg: if (!Admin::permission()->permissionIntercept($LiCd2, $wjHv9)) { goto s2qvp; } goto t5STX; T90ay: } }
