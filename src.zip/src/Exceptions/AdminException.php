<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:28              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Exceptions; use DagaSmart\BizAdmin\Admin; use Exception; class AdminException extends Exception { private $data; private $doNotDisplayToast; public function __construct($FgAEc = '', $Uv4qm = array(), $c3I_7 = 0) { goto fmjBD; fmjBD: parent::__construct($FgAEc); goto zn3zl; Fbcvc: $this->doNotDisplayToast = $c3I_7; goto aM3ZB; zn3zl: $this->data = $Uv4qm; goto Fbcvc; aM3ZB: } public function render() { return Admin::response()->doNotDisplayToast($this->doNotDisplayToast)->fail($this->getMessage(), $this->data); } public function report() { } }
