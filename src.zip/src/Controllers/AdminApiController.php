<?php
/*
    |__________________________________________________
    |  DagaSmart CE pro by 3.0.17  |
    |  Authorization on 2026-03-22 00:00:28              |
    |  GitHub: https://github.com/dagasmart/bizadmin    |
    |  Tel: 13511953492   |
    |  Email: dagasmart@qq.com   |
    |__________________________________________________|
*/
 namespace DagaSmart\BizAdmin\Controllers; use DagaSmart\BizAdmin\Admin; use Illuminate\Support\Str; use DagaSmart\BizAdmin\Services\AdminApiService; class AdminApiController extends AdminController { public string $serviceName = AdminApiService::class; public function index() { goto hta19; L3S9B: $yXxid = $this->service->getApiByPath($ICl39); goto V1WJG; V1WJG: if ($yXxid) { goto Pdpzp; } goto YMuT2; Qk6mR: return app($yXxid->template)->setApiRecord($yXxid)->handle(); goto J9qwj; hta19: $ICl39 = Str::of(request()->path())->replace(Admin::config("\x61\x64\x6d\151\156\56\162\x6f\x75\x74\x65\x2e\160\x72\145\x66\151\170"), '')->value(); goto L3S9B; YMuT2: return $this->response()->success(); goto AU0xV; AU0xV: Pdpzp: goto Qk6mR; J9qwj: } }
